﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.BLL;

namespace WindowsFormsApp1
{
    public partial class FormStudent : Form
    {
        public FormStudent()
        {
            InitializeComponent();
        }

        //private void buttonShow_Click(object sender, EventArgs e)
        //{
        //    Student student = new Student();
        //    student.StudentId = 1234567;
        //    student.FirstName = "Mary";
        //    student.LastName = "Brown";
        //    MessageBox.Show(student.StudentId + "\n" + student.FirstName + "\n" + student.LastName);


        //}
    }
}
