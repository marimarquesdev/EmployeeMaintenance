﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using lab1_Version2.BLL;


namespace lab1_Version2.DAL
{
    static class EmployeeDA
    {
        static string filePath = Application.StartupPath + @"\employee.bat";
        public static void SaveRecord(Employee employee)
        {
            StreamWriter sw = new StreamWriter(filePath, true);
            sw.WriteLine(employee.EmployeeID+ ","+employee.FirstName+","+employee.LastName+","+employee.JobTitle);
            sw.Close();
        }

        public static bool IsDuplicateId(int id)
        {
            //check if the file exists
            if (File.Exists(filePath))
            {
                // create the object of type StreamReader
                StreamReader sr = new StreamReader(filePath);
                //read the first line
                string line = sr.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    if (Convert.ToInt32(fields[0]) == id)
                    {
                        sr.Close();
                        MessageBox.Show("Duplicate Id", "Invalid Id");
                        return true;
                    }
                    //read the next line
                    line = sr.ReadLine();
                }
                sr.Close();
                return false; // Id is OK
            }
            else
            {
                MessageBox.Show("File not found!");
            }
            return false;

        }

        public static Employee Search(long id)
        {
            Employee employee = new Employee();
            
            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, true);
                string line = sr.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    if (id == Convert.ToInt32(fields[0]))
                    {
                        employee.EmployeeID = Convert.ToInt32(fields[0]);
                        employee.FirstName = fields[1];
                        employee.LastName = fields[2];
                        employee.JobTitle = fields[3];
                        sr.Close();
                        return employee;
                    }
                    line = sr.ReadLine();
                }
                   
                        employee = null;
                        MessageBox.Show("Employee not found!", "Alert");

            }
            else
            {
                MessageBox.Show("File not found!", "Error");
            }
            return employee;
        }

        public static Employee SearchFirstName(string firstName)
        {
            Employee employee = new Employee();

            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, true);
                string line = sr.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    if (firstName == fields[1])
                    {
                        employee.EmployeeID = Convert.ToInt32(fields[0]);
                        employee.FirstName = fields[1];
                        employee.LastName = fields[2];
                        employee.JobTitle = fields[3];
                        sr.Close();
                        return employee;
                    }
                    line = sr.ReadLine();
                }

               // employee = null;
                MessageBox.Show("Employee not found!", "Alert");

            }
            else
            {
                MessageBox.Show("File not found!", "Error");
            }
            return employee;
        }

        public static Employee SearchLastName(string lastName)
        {
            Employee employee = new Employee();

            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, true);
                string line = sr.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    if (lastName == fields[2])
                    {
                        employee.EmployeeID = Convert.ToInt32(fields[0]);
                        employee.FirstName = fields[1];
                        employee.LastName = fields[2];
                        employee.JobTitle = fields[3];
                        sr.Close();
                        return employee;
                    }
                    line = sr.ReadLine();
                }

                // employee = null;
                MessageBox.Show("Employee not found!", "Alert");

            }
            else
            {
                MessageBox.Show("File not found!", "Error");
            }
            return employee;
        }
        public static Employee SearchFullName(string firstName, string lastName)
        {
            Employee employee = new Employee();

            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, true);
                string line = sr.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    if (firstName == fields[1] && lastName == fields[2])
                    {
                        employee.EmployeeID = Convert.ToInt32(fields[0]);
                        employee.FirstName = fields[1];
                        employee.LastName = fields[2];
                        employee.JobTitle = fields[3];
                        sr.Close();
                        return employee;
                    }
                    line = sr.ReadLine();
                }

                // employee = null;
                MessageBox.Show("Employee not found!", "Alert");

            }
            else
            {
                MessageBox.Show("File not found!", "Error");
            }
            return employee;
        }
        public static List<Employee> List()
        {
            List<Employee> listEmployee = new List<Employee>() ;
            Employee employee = new Employee();

            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(filePath, true);
                                
                string line = sr.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    employee.EmployeeID = Convert.ToInt32(fields[0]);
                    employee.FirstName = fields[1];
                    employee.LastName = fields[2];
                    employee.JobTitle = fields[3];
                    listEmployee.Add(employee);
                    return listEmployee;
                }
                sr.Close();
                
            }
            else
            {
                MessageBox.Show("File not found!", "Error");
            }

            return listEmployee;
        }
    }
}
